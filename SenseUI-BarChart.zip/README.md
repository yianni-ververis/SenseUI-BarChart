# SenseUI-BarChart

A more elegant and Mobile Friendly Bar Chart for Qlik Sense

![SenseUI - Bar Chart](/preview.png?raw=true "SenseUI - Bar Chart")

## If you have more than one measure, it becomes a stacked bar

![SenseUI - Bar Chart](/stackedBar.png?raw=true "Stacked Bar")

## Or convert it into a Lollipop
![SenseUI - Bar Chart](/lollipop.png?raw=true "Lollipop")

[Download zip file](https://github.com/yianni-ververis/SenseUI-BarChart/archive/master.zip)